#include "AuralisationComponent.h"

#include "../JuceLibraryCode/JuceHeader.h"
#include "MainComponent.h"
#include "Utils.h"

///////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////

AuralisationComponent::AuralisationComponent()
{
	labelAuralisation.setText("Auralisation", dontSendNotification);
	addAndMakeVisible(labelAuralisation);
	
	labelDirectPathGain.setText("Direct path gain", dontSendNotification);
	labelDirectPathGain.setJustificationType(Justification::right);
	addAndMakeVisible(labelDirectPathGain);

	labelEarlyReflectionsGain.setText("Early reflections gain", dontSendNotification);
	labelEarlyReflectionsGain.setJustificationType(Justification::right);
	addAndMakeVisible(labelEarlyReflectionsGain);
	
	labelReverbTail.setText("Reverb tail gain", dontSendNotification);
	labelReverbTail.setJustificationType(Justification::right);
	addAndMakeVisible(labelReverbTail);

	labelCrossfadeFactor.setText("Crossfade factor", dontSendNotification);
	labelCrossfadeFactor.setJustificationType(Justification::right);
	addAndMakeVisible(labelCrossfadeFactor);
	
	labelNumFrequencyBands.setText("Frequency bands", dontSendNotification);
	addAndMakeVisible(labelNumFrequencyBands);

	labelSourceDirectivity.setText("Source directivity", dontSendNotification);
	addAndMakeVisible(labelSourceDirectivity);

	buttonSaveRIR.setButtonText("Save RIR");
	buttonSaveRIR.addListener(this);
	buttonSaveRIR.setEnabled(true);
	addAndMakeVisible(buttonSaveRIR);

	buttonClearSourceImage.setButtonText("Clear source");
	buttonClearSourceImage.addListener(this);
	buttonClearSourceImage.setEnabled(true);
	addAndMakeVisible(buttonClearSourceImage);

	buttonReverbTail.setButtonText("Enable reverb tail");
	buttonReverbTail.addListener(this);
	buttonReverbTail.setEnabled(true);
	buttonReverbTail.setToggleState(true, dontSendNotification);
	addAndMakeVisible(buttonReverbTail);
	
	buttonDirectToBinaural.setButtonText("Direct to binaural");
	buttonDirectToBinaural.addListener(this);
	buttonDirectToBinaural.setEnabled(true);
	buttonDirectToBinaural.setToggleState(false, dontSendNotification);
	addAndMakeVisible(buttonDirectToBinaural);

	comboNumFrequencyBands.setEditableText(false);
	comboNumFrequencyBands.setJustificationType(Justification::right);
	comboNumFrequencyBands.addListener(this);
	comboNumFrequencyBands.addItemList({"3", "10"}, 1);
	comboNumFrequencyBands.setSelectedId(1);
	addAndMakeVisible(comboNumFrequencyBands);

	comboSourceDirectivity.setEditableText(false);
	comboSourceDirectivity.setJustificationType(Justification::right);
	comboSourceDirectivity.addListener(this);
	comboSourceDirectivity.addItemList({ "omni", "directional" }, 1);
	comboSourceDirectivity.setSelectedId(1);
	addAndMakeVisible(comboSourceDirectivity);

	sliderDirectPathGain.setRange(0.0, 2.0);
	sliderDirectPathGain.setValue(1.0);
	sliderDirectPathGain.setSliderStyle(Slider::LinearHorizontal);
	sliderDirectPathGain.setTextBoxStyle(Slider::TextBoxRight, true, 70, 20);
	sliderDirectPathGain.addListener(this);
	addAndMakeVisible(sliderDirectPathGain);
	
	sliderEarlyReflectionsGain.setRange(0.0, 2.0);
	sliderEarlyReflectionsGain.setValue(1.0);
	sliderEarlyReflectionsGain.setSliderStyle(Slider::LinearHorizontal);
	sliderEarlyReflectionsGain.setTextBoxStyle(Slider::TextBoxRight, true, 70, 20);
	sliderEarlyReflectionsGain.addListener(this);
	addAndMakeVisible(sliderEarlyReflectionsGain);
	
	sliderReverbTailGain.setRange(0.0, 2.0);
	sliderReverbTailGain.setValue(1.0);
	sliderReverbTailGain.setSliderStyle(Slider::LinearHorizontal);
	sliderReverbTailGain.setTextBoxStyle(Slider::TextBoxRight, true, 70, 20);
	sliderReverbTailGain.addListener(this);
	addAndMakeVisible(sliderReverbTailGain);

	sliderCrossfadeFactor.setRange(0.01, 0.2);
	sliderCrossfadeFactor.setValue(0.1);
	sliderCrossfadeFactor.setSliderStyle(Slider::LinearHorizontal);
	sliderCrossfadeFactor.setTextBoxStyle(Slider::TextBoxRight, true, 70, 20);
	sliderCrossfadeFactor.setSkewFactor(0.7);
	sliderCrossfadeFactor.addListener(this);
	addAndMakeVisible(sliderCrossfadeFactor);
}

///////////////////////////////////////////////////////////////////////////////////////////////////

void AuralisationComponent::buttonClicked(Button* button)
{
	auto parent = dynamic_cast<MainComponent*>(getParentComponent());

	if (button == &buttonSaveRIR)
	{
		parent->saveRIR();
	}
	else if (button == &buttonClearSourceImage)
	{
		parent->clearSourceImage();
	}
	else if (button == &buttonReverbTail)
	{
		bool enable = button->getToggleState();
		sliderReverbTailGain.setEnabled(enable);
		parent->enableReverbTail(enable);
	}
	else if (button == &buttonDirectToBinaural)
	{
		bool enable =button->getToggleState();
		parent->enableDirectToBinaural(enable);
	}
}

///////////////////////////////////////////////////////////////////////////////////////////////////

void AuralisationComponent::comboBoxChanged(ComboBox* comboBox)
{
	auto parent = dynamic_cast<MainComponent*>(getParentComponent());

	if (comboBox == &comboNumFrequencyBands)
	{
		int value = comboBox->getText().getIntValue();
		parent->updateNumFrequencyBands(value);
	}
	else if (comboBox == &comboSourceDirectivity)
	{
		String value = comboBox->getText();
		parent->updateSourceDirectivity(value);
	}
}

///////////////////////////////////////////////////////////////////////////////////////////////////

void AuralisationComponent::sliderValueChanged(Slider* slider)
{
	auto parent = dynamic_cast<MainComponent*>(getParentComponent());

	if (slider == &sliderDirectPathGain)
	{
		parent->updateDirectPathGain(slider->getValue());
	}
	else if (slider == &sliderEarlyReflectionsGain)
	{
		parent->updateEarlyReflectionsGain(slider->getValue());
	}
	else if (slider == &sliderReverbTailGain)
	{
		parent->updateReverbTailGain(slider->getValue());
	}
	else if(slider == &sliderCrossfadeFactor)
	{
		parent->updateCrossfadeFactor(slider->getValue());
	}
}

///////////////////////////////////////////////////////////////////////////////////////////////////

void AuralisationComponent::paint(Graphics& g)
{
	g.setColour(Colours::white);
	g.drawRoundedRectangle(10, 10, getWidth() - 20, getHeight() - 20,
		getParentComponent()->getHeight() / 100, 2.0);
}

///////////////////////////////////////////////////////////////////////////////////////////////////

void AuralisationComponent::resized()
{
	int h = (getHeight() - 40) / 5;
	int w = (getWidth() - 40) / 20;

	Font labelFont = labelAuralisation.getFont();
	labelAuralisation.setBounds(30, 5, 1.2 * labelFont.getStringWidth(labelAuralisation.getText()), labelFont.getHeight());
	
	labelDirectPathGain.setBounds(20, 20, 4 * w, h);
	labelEarlyReflectionsGain.setBounds(20, 20 + h, 4 * w, h);
	labelReverbTail.setBounds(20, 20 + 2 * h, 4 * w, h);
	labelCrossfadeFactor.setBounds(20, 20 + 3 * h, 4 * w, h);
	buttonReverbTail.setBounds(20, 20 + 4 * h, 4 * w, h);
	sliderDirectPathGain.setBounds(20 + 4 * w, 20, 16 * w, h);
	sliderEarlyReflectionsGain.setBounds(20 + 4 * w, 20 + h, 16 * w, h);
	sliderReverbTailGain.setBounds(20 + 4 * w, 20 + 2 * h, 16 * w, h);
	sliderCrossfadeFactor.setBounds(20 + 4 * w, 20 + 3 * h, 16 * w, h);
	buttonDirectToBinaural.setBounds(20 + 4 * w, 20 + 4 * h, 4 * w, h);
	labelNumFrequencyBands.setBounds(20 + 8 * w, 20 + 4 * h, 4 * w, h / 2);
	labelSourceDirectivity.setBounds(20 + 8 * w, 20 + 4.5 * h, 4 * w, h / 2);
	comboNumFrequencyBands.setBounds(20 + 12 * w, 20 + 4 * h, 2 * w, h / 2);
	comboSourceDirectivity.setBounds(20 + 12 * w, 20 + 4.5 * h, 2 * w, h / 2);
	buttonSaveRIR.setBounds(pad(20 + 14 * w, 20 + 4 * h, 3 * w, h));
	buttonClearSourceImage.setBounds(pad(20 + 17 * w, 20 + 4 * h, 3 * w, h));
}

///////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////