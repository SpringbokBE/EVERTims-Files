#include "LedComponent.h"

///////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////

LedComponent::LedComponent() :
	state(State::notClipped)
{
	isClipped = false;
	startTimer(timerUpdateIntervalInMs);
}

///////////////////////////////////////////////////////////////////////////////////////////////////

void LedComponent::paint(Graphics& g)
// Paint callback associated to this component, draw source image, user head, etc.
{
	g.setColour(Colours::dimgrey);
	g.drawEllipse(3.0, 7.0, 8.0, 8.0, 2.0);

	if (isClipped)
	{
		isClipped = false;
		state = State::clipped;
		nextUnclipTime = Time::getMillisecondCounter() + ledFadeDuration;
	}
	else if (Time::getMillisecondCounter() >= nextUnclipTime)
	{
		state = State::notClipped;
	}

	if(state == State::clipped)
	{
		g.setColour(Colours::red);
		g.fillEllipse(3.7, 7.6, 7.0, 7.0);
	}
	else if(state == State::notClipped)
	{
		g.setColour(Colours::dimgrey);
		g.fillEllipse(3.7, 7.6, 7.0, 7.0);
	}
}

///////////////////////////////////////////////////////////////////////////////////////////////////

void LedComponent::timerCallback()
// get owner clip state
{
	repaint();
}

///////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////